//
//  StockTradeToastView.swift
//  slava-stock-watch
//
//  Created by Slava Zinevich on 5/2/22.
//

import SwiftUI
import AlertToast

struct StockTradeToastView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
    
    init(_ message : String){
        
    }
}

struct StockTradeToastView_Previews: PreviewProvider {
    static var previews: some View {
        StockTradeToastView()
    }
}
