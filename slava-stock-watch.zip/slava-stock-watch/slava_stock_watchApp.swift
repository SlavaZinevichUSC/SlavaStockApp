//
//  slava_stock_watchApp.swift
//  slava-stock-watch
//
//  Created by Slava Zinevich on 4/19/22.
//

import SwiftUI

@main
struct slava_stock_watchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

