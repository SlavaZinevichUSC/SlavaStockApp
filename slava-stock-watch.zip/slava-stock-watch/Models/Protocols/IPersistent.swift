//
//  IPersistent.swift
//  slava-stock-watch
//
//  Created by Slava Zinevich on 5/2/22.
//

import Foundation


protocol IPersistent{
    var url : URL? { get }
}
